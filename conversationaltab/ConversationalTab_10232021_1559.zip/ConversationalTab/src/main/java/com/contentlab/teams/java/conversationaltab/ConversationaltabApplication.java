package com.contentlab.teams.java.conversationaltab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversationaltabApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversationaltabApplication.class, args);
	}

}
