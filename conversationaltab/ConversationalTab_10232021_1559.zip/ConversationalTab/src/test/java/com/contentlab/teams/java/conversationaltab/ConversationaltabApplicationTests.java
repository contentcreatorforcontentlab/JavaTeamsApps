package com.contentlab.teams.java.conversationaltab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversationaltabApplicationTests {

	@Test
	void contextLoads() {
	}

}
